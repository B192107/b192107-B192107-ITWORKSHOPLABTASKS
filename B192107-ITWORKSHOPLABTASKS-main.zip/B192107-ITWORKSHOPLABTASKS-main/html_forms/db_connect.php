<?php
$server="localhost";
$username="root";
$password="";
$db="student";
$conn=mysqli_connect($server,$username,$password,$db);
if(!$conn)
{
 echo "unsuccessfull connection";
}
else{
      echo "connected successfully";
}
?>
